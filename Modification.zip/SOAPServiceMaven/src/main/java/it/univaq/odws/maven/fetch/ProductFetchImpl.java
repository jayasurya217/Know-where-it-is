package it.univaq.odws.maven.fetch;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.*;
import java.io.*;

import javax.jws.WebService;

@WebService(endpointInterface = "it.univaq.odws.maven.fetch.ProductFetch")
public class ProductFetchImpl implements ProductFetch {
	private String shopName;
	private String productName;
	private String shopAdress;
	private String userAdress;
	private Integer productOrder;
	private String distance;
	private String duration;
	private String shopLocationLink;
	private int productId;
	private Double productPrice;
	private String shopAddress;

	public ProductFetchImpl(String shopName, String productName, String shopAdress, String userAdress, Integer productOrder,
			String distance, String duration, String shopLocationLink, int productId, Double productPrice,
			String shopAddress) {
		super();
		this.shopName = shopName;
		this.productName = productName;
		this.shopAdress = shopAdress;
		this.userAdress = userAdress;
		this.productOrder = productOrder;
		this.distance = distance;
		this.duration = duration;
		this.shopLocationLink = shopLocationLink;
		this.productId = productId;
		this.productPrice = productPrice;
		this.shopAddress = shopAddress;
	}

	public ProductFetchImpl() {
		super();
	}

	public static List<ProductFetchImpl> fetch(String product_name, int user_id) throws JSONException {
		JSONArray ja = new JSONArray();
		List<ProductFetchImpl> lista = new ArrayList<>();
		JSONArray resultArray = new JSONArray();
		try {

			// establishing mysql connection
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/prueba?characterEncoding=latin1&autoReconnect=true&useSSL=false",
					"root", "123456");
			System.out.println("established sql connection");

			// selecting all the products with product_name
			Statement stmt1 = con.createStatement();
			ResultSet rs = stmt1.executeQuery("select * from product where product_name='" + product_name + "'");

			// Iterating over each product to calculate their order and put in a json
			while (rs.next()) {

				JSONObject jo = new JSONObject();

				// putting product_id, name and price in json object
				jo.put("ProductID", rs.getInt(1));
				jo.put("ProductName", rs.getString(2));
				jo.put("ProductPrice", rs.getDouble(3));

				int shop_id = rs.getInt(6);
				Double prod_price = rs.getDouble(3);

				Statement stmt2 = con.createStatement();
				ResultSet shop = stmt2.executeQuery("select * from users where id=" + shop_id);
				shop.next();
				String shop_address = "" + shop.getString(22) + "," + shop.getString(21) + "," + shop.getString(20);

				shop_address = shop_address.replace(" ", "+");

				// Fetching user details for location
				Statement stmt3 = con.createStatement();
				ResultSet user = stmt3.executeQuery("select * from users where id=" + user_id);
				user.next();
				String user_address = "" + user.getString(22) + "," + user.getString(21) + "," + user.getString(20);

				user_address = user_address.replace(" ", "+");

				// Using google maps distance matrix api for getting the distance and time
				URL google_url = new URL(
						"https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins="
								+ user_address + "&destinations=" + shop_address
								+ "&key=AIzaSyCoyTizGFhuvrnQWPT_osZNUYNXH-sE_Zk");
				HttpURLConnection conection = (HttpURLConnection) google_url.openConnection();
				conection.setRequestMethod("GET");
				int responseCode = conection.getResponseCode();
				String message = conection.getResponseMessage();
				if (responseCode == HttpURLConnection.HTTP_OK) { // success
					BufferedReader in = new BufferedReader(new InputStreamReader(conection.getInputStream()));
					String inputLine;
					StringBuffer response = new StringBuffer();

					while ((inputLine = in.readLine()) != null) {
						response.append(inputLine);
					}
					in.close();

					JSONObject obj = new JSONObject(response.toString());

					JSONArray arr = obj.getJSONArray("rows");
					JSONObject elements = arr.getJSONObject(0);

					JSONArray elem = elements.getJSONArray("elements");
					JSONObject result = elem.getJSONObject(0);

					int distance = result.getJSONObject("distance").getInt("value");
					String dist = result.getJSONObject("distance").getString("text");
					String duration = result.getJSONObject("duration").getString("text");

					distance = (int) (distance * 0.001);
					int prod_order = (int) (prod_price * distance);

					jo.put("ShopName", shop.getString(3));
					jo.put("ProductOrder", prod_order);
					jo.put("ShopAdress", shop_address);
					jo.put("UserAddress", user_address);
					jo.put("Distance", dist);
					jo.put("Duration", duration);

					String ShopLocation = "https://www.google.com/maps/search/?api=1&query=" + shop_address;
					jo.put("ShopLocationLink", ShopLocation);

					ProductFetchImpl p = new ProductFetchImpl(shop.getString(3), rs.getString(2), shop_address,
							user_address, prod_order, dist, duration, ShopLocation, rs.getInt(1), rs.getDouble(3),
							shop_address);
					lista.add(p);

				} else {
					System.out.println("GET request not worked");
				}
			}

			con.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e);
		}
		Comparator<ProductFetchImpl> byProductOrder = 
				(ProductFetchImpl o1, ProductFetchImpl o2)->o1.getProductOrder().compareTo(o2.getProductOrder());
		Collections.sort(lista, byProductOrder);
		return lista;
	}

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getShopAdress() {
		return shopAdress;
	}

	public void setShopAdress(String shopAdress) {
		this.shopAdress = shopAdress;
	}

	public String getUserAdress() {
		return userAdress;
	}

	public void setUserAdress(String userAdress) {
		this.userAdress = userAdress;
	}

	public Integer getProductOrder() {
		return productOrder;
	}

	public void setProductOrder(Integer productOrder) {
		this.productOrder = productOrder;
	}

	public String getDistance() {
		return distance;
	}

	public void setDistance(String distance) {
		this.distance = distance;
	}

	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	public String getShopLocationLink() {
		return shopLocationLink;
	}

	public void setShopLocationLink(String shopLocationLink) {
		this.shopLocationLink = shopLocationLink;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public Double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(Double productPrice) {
		this.productPrice = productPrice;
	}

	public String getShopAddress() {
		return shopAddress;
	}

	public void setShopAddress(String shopAddress) {
		this.shopAddress = shopAddress;
	}

	@Override
	public String toString() {
		return "ProductFetchImpl [shopName=" + shopName + ", productName=" + productName + ", shopAdress=" + shopAdress
				+ ", userAdress=" + userAdress + ", productOrder=" + productOrder + ", distance=" + distance
				+ ", duration=" + duration + ", shopLocationLink=" + shopLocationLink + ", productId=" + productId
				+ ", productPrice=" + productPrice + ", shopAddress=" + shopAddress + "]";
	}
}
