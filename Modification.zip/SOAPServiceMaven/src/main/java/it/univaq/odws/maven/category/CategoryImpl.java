package it.univaq.odws.maven.category;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Future;

import javax.xml.ws.AsyncHandler;
import javax.xml.ws.Response;

import org.apache.cxf.annotations.UseAsyncMethod;
import org.apache.cxf.jaxws.ServerAsyncResponse;

public class CategoryImpl implements Category {
	private static final String user = "root";
	private static final String password = "123456";

	private int categoryId;
	private String caterogyName;

	public CategoryImpl() {
		super();
	}

	public CategoryImpl(int categoryId, String caterogyName) {
		super();
		this.categoryId = categoryId;
		this.caterogyName = caterogyName;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getCaterogyName() {
		return caterogyName;
	}

	public void setCaterogyName(String caterogyName) {
		this.caterogyName = caterogyName;
	}

	@Override
	public String toString() {
		return "CategoryImpl [categoryId=" + categoryId + ", caterogyName=" + caterogyName + "]";
	}

	Locale locale = new Locale("it", "IT");
	DateFormat formatter = DateFormat.getTimeInstance(DateFormat.DEFAULT, locale);

	@Override
	@UseAsyncMethod
	public List<CategoryImpl> sendCategoriesWithReturn() {
		System.out.println(formatter.format(new Date()) + " Executing sendCategoriesWithReturn asynchronously");
		{
			List<CategoryImpl> categories = new ArrayList<>();
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection(
						"jdbc:mysql://localhost:3306/prueba?characterEncoding=latin1&autoReconnect=true&useSSL=false",
						user, password);
				// here prueba is database name, root is username and password
				Statement stmt = con.createStatement();
				ResultSet result = stmt.executeQuery("SELECT * FROM category;");
				while (result.next()) {
					CategoryImpl category = new CategoryImpl(result.getInt(1), result.getString(2));
					categories.add(category);

				}
				con.close();
			} catch (Exception e) {
				System.out.println(e);
			}
			return categories;
		}
	}

	@Override
	public Response<Categories> sendCategoriesWithReturnAsync() {
		System.out.println(formatter.format(new Date())
				+ " Executing sendCategoriesWithResponse asynchronously");
		return null;
	}

	@Override
	public Future<?> sendCategoriesWithReturnAsync(AsyncHandler<Categories> asyncHandler) {
		System.out.println(formatter.format(new Date()) + " Executig sendCategoriesWithReturnAsync with AsyncHandler asynchronously");
		final ServerAsyncResponse<Categories> asyncResponse = new ServerAsyncResponse<Categories> ();
		new Thread() {
			public void run() {
				try {
					Thread.sleep(10000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				Categories response = new Categories();
				 
						List<CategoryImpl> categories = new ArrayList<>();
						try {
							Class.forName("com.mysql.jdbc.Driver");
							Connection con = DriverManager.getConnection(
									"jdbc:mysql://localhost:3306/prueba?characterEncoding=latin1&autoReconnect=true&useSSL=false", user,
									password);
							// here prueba is database name, root is username and password
							Statement stmt = con.createStatement();
							ResultSet result = stmt.executeQuery("SELECT * FROM category;");
							while (result.next()) {
								CategoryImpl category = new CategoryImpl(result.getInt(1), result.getString(2));
								categories.add(category);

							}
							con.close();
						} catch (Exception e) {
							System.out.println(e);
						}
					
				response.setCategories(categories);
				asyncResponse.set(response);
				
				System.out.println(formatter.format(new Date()) + " Responding on the background thread");
				asyncHandler.handleResponse(asyncResponse);
			}
			
		}.start();
		return asyncResponse;
	}

}
