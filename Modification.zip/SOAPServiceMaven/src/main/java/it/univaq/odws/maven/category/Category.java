package it.univaq.odws.maven.category;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Future;

import javax.jws.WebMethod;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.ws.AsyncHandler;
import javax.xml.ws.Response;
import javax.xml.ws.ResponseWrapper;


@WebService
public interface Category {
	
	@WebMethod
	@ResponseWrapper (localName = "Categories",
	className = "it.univaq.odws.maven.category.Categories")
	public List<CategoryImpl> sendCategoriesWithReturn();
	

	@WebMethod
	@ResponseWrapper (localName = "Categories",
	className = "it.univaq.odws.maven.category.Categories")
	public Response<Categories> sendCategoriesWithReturnAsync();
	
	@WebMethod
	@ResponseWrapper (localName = "Categories",
	className = "it.univaq.odws.maven.category.Categories")
	public Future<?> sendCategoriesWithReturnAsync(
			AsyncHandler<Categories> asyncHandler);
	
	

}
