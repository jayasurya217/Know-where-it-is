package it.univaq.odws.maven.product;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.servlet.ServletConfig;
import javax.xml.ws.Endpoint;

import org.apache.cxf.Bus;
import org.apache.cxf.BusFactory;
import org.apache.cxf.transport.servlet.CXFNonSpringServlet;

import it.univaq.odws.maven.category.CategoryImpl;
import it.univaq.odws.maven.fetch.ProductFetchImpl;
import it.univaq.odws.maven.product.ProductImpl;

public class SimpleCXFNonSpringServlet extends CXFNonSpringServlet {

	private static final long serialVersionUID = 1152463856246372604L;

	public void loadBus(ServletConfig servletConfig) {
		super.loadBus(servletConfig);
		Bus bus = getBus();
		BusFactory.setDefaultBus(bus);
		ExecutorService executorService = Executors.newFixedThreadPool(5);
		Endpoint endpoint = Endpoint.create(new ProductFetchImpl());
		endpoint.setExecutor(executorService);
		endpoint.publish("/ProductFetch");
		Endpoint.publish("/Product", new ProductImpl());
		Endpoint.publish("/Category", new CategoryImpl());
	}
}
