package it.univaq.odws.maven.category;

import java.util.List;

public class Categories {
	private List<CategoryImpl> categories;

	public List<CategoryImpl> getCategories() {
		return categories;
	}

	public void setCategories(List<CategoryImpl> categories) {
		this.categories = categories;
	}

}
