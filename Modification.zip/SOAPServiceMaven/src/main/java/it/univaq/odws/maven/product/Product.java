package it.univaq.odws.maven.product;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

@WebService
public interface Product {

	@WebMethod
	@WebResult(name = "ListOfProducts")
	static List<ProductImpl> getAll() {
		return new ArrayList<>();
	}

	@WebMethod
	@WebResult(name = "ListOfProductsLimit")
	static List<ProductImpl> getProductsLimit(@WebParam(name = "NumbersOfRowsToReturn") Integer numberOfRowsToReturn,
			@WebParam(name = "InitialRow") Integer startInRow) {
		return new ArrayList<>();
	}

	@WebMethod
	@WebResult(name = "Product")
	static ProductImpl getProductById(@WebParam(name = "productId") Integer productId) {
		return null;
	}

	@WebMethod
	@WebResult(name = "Product")
	static ProductImpl getProductByName(@WebParam(name = "productName") String productName) {
		return null;
	}

	
	@WebMethod
	static String updateProduct(@WebParam(name = "productId") Integer productId,
			@WebParam(name = "productName") String productName,
			@WebParam(name = "productCategory") String productCategory,
			@WebParam(name = "productImage") String productImage, @WebParam(name = "productPrice") Double productPrice,
			@WebParam(name = "shopId") String shopId, @WebParam(name = "productCount") Integer productCount) {
		return new String();
	}

	
	@WebMethod
	static String updateProductName(@WebParam(name = "productId") Integer productId,
			@WebParam(name = "productName") String productName) {
		return new String();
	}

	
	@WebMethod
	static String updateProductCategory(@WebParam(name = "productId") Integer productId,
			@WebParam(name = "productCategory") Integer productCategory) {
		return new String();
	}

	
	@WebMethod
	static String updateProductImage(@WebParam(name = "productId") Integer productId,
			@WebParam(name = "productImage") String productImage) {
		return new String();
	}

	
	@WebMethod
	static String updateProductPrice(@WebParam(name = "productId") Integer productId,
			@WebParam(name = "productPrice") Double productPrice) {
		return new String();
	}

	
	@WebMethod
	static String updateProductCount(@WebParam(name = "productId") Integer productId,
			@WebParam(name = "productCount") Integer productCount) {
		return new String();
	}

	
	@WebMethod
	static String deleteProductById(@WebParam(name = "productId") Integer productId) {
		return new String();
	}

	
	@WebMethod
	static String deleteProductByName(@WebParam(name = "productName") String productName) {
		return new String();
	}

	
	@WebMethod
	static String addNewProduct(@WebParam(name = "productName") String productName,
			@WebParam(name = "productPrice") Double productPrice, @WebParam(name = "productCount") Integer productCount,
			@WebParam(name = "productCategory") Integer productCategory, @WebParam(name = "shopId") Integer shopId,
			@WebParam(name = "productImage") String productImage) {
		return new String();
	}
}
