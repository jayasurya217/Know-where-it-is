package it.univaq.odws.maven.fetch;

import java.util.ArrayList;
import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import java.sql.SQLException;

@WebService
public interface ProductFetch {
	@WebMethod
	 static List<ProductFetchImpl> fetch (@WebParam(name="ProductName")String product_name,@WebParam(name="UserId")int user_id) throws SQLException {
		return new ArrayList<>();
	}

}

