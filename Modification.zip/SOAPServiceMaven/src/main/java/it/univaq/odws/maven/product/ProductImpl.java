package it.univaq.odws.maven.product;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.sun.istack.Nullable;

import it.univaq.odws.maven.product.Product;


public class ProductImpl implements Product {

	private static final String user = "root";
	private static final String password = "123456";

	private int productId;
	private String productName;
	private Double productPrice;
	private int productCount;
	private int productCategory;
	private int shopId;
	private String productImage;

	public ProductImpl() {
		super();
	}

	public ProductImpl(int productId, String productName, Double productPrice, int productCount, int productCategory,
			int shopId, String productImage) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productCount = productCount;
		this.productCategory = productCategory;
		this.shopId = shopId;
		this.productImage = productImage;
	}

	public static String addNewProduct(String productName, @Nullable Double productPrice,
			@Nullable Integer productCount, Integer productCategory, Integer shopId, String productImage) {
		String result = "";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/prueba?characterEncoding=latin1&autoReconnect=true&useSSL=false", user,
					password);
			// here prueba is database name, root is username and password
			Statement stmt = con.createStatement();
			Statement stmt1 = con.createStatement();
			Statement stmt2 = con.createStatement();
			ResultSet r1 = stmt1.executeQuery("SELECT count(*) from product;");
			r1.next();
			Integer n1 = r1.getInt(1);
			stmt.executeUpdate("INSERT INTO product (`product_id`,`product_name`,`category_id`, `product_image`,"
					+ "`product_price`, `store_id`, `product_count`) VALUES " + "(" + "NULL" + "," + "'" + productName
					+ "'" + "," + "'" + productCategory + "'" + "," + "'" + productImage + "'" + "," + productPrice
					+ "," + "'" + shopId + "'," + productCount + ")" + ";");
			ResultSet r2 = stmt2.executeQuery("SELECT count(*) from product;");
			r2.next();
			Integer n2 = r2.getInt(1);
			con.close();
			if (n1 != n2) {
				result = "Product " + productName + " added";
			} else {
				result = "Product " + productName + "not added";

			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return result;
	}

	public static String updateProduct(Integer productId, String productName, String productCategory,
			String productImage, Double productPrice, String shopId, Integer productCount) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/prueba?characterEncoding=latin1&autoReconnect=true&useSSL=false", user,
					password);
			// here prueba is database name, root is username and password
			Statement stmt = con.createStatement();
			stmt.executeUpdate("UPDATE product SET `product_name`='" + productName + "' ," + "`category_id`='"
					+ productCategory + "' ," + "`product_image`='" + productImage + "' ," + "`product_price`="
					+ productPrice + " ," + "`store_id`='" + shopId + "`product_count`=" + productCount
					+ "' WHERE `product_id`='" + productId + "' ;");
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return "Product " + productName + " updated";
	}

	public static String updateProductName(Integer productId, String productName) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/prueba?characterEncoding=latin1&autoReconnect=true&useSSL=false", user,
					password);
			// here prueba is database name, root is username and password
			Statement stmt = con.createStatement();
			stmt.executeUpdate(
					"UPDATE product SET `product_name`='" + productName + "' WHERE `product_id`='" + productId + "' ;");
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return "Product " + productName + " updated";
	}

	public static String updateProductCategory(Integer productId, Integer productCategory) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/prueba?characterEncoding=latin1&autoReconnect=true&useSSL=false", user,
					password);
			// here prueba is database name, root is username and password
			Statement stmt = con.createStatement();
			stmt.executeUpdate("UPDATE product SET `category_id`='" + productCategory + "' WHERE `product_id`='"
					+ productId + "' ;");
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return "Category of  " + productId + " updated";
	}

	public static String updateProductImage(Integer productId, String productImage) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/prueba?characterEncoding=latin1&autoReconnect=true&useSSL=false", user,
					password);
			// here prueba is database name, root is username and password
			Statement stmt = con.createStatement();
			stmt.executeUpdate("UPDATE product SET `product_image`='" + productImage + "' WHERE `product_id`='"
					+ productId + "' ;");
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return "Image of  " + productId + " updated";
	}

	public static String updateProductPrice(Integer productId, Double productPrice) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/prueba?characterEncoding=latin1&autoReconnect=true&useSSL=false", user,
					password);
			// here prueba is database name, root is username and password
			Statement stmt = con.createStatement();
			stmt.executeUpdate("UPDATE product SET `product_price`='" + productPrice + "' WHERE `product_id`='"
					+ productId + "' ;");
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return "Price of  " + productId + " updated";
	}

	public static String updateProductCount(Integer productId, Integer productCount) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/prueba?characterEncoding=latin1&autoReconnect=true&useSSL=false", user,
					password);
			// here prueba is database name, root is username and password
			Statement stmt = con.createStatement();
			stmt.executeUpdate("UPDATE product SET `product_count`='" + productCount + "' WHERE `product_id`='"
					+ productId + "' ;");
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return "Count of  " + productId + " updated";
	}

	public static String deleteProductById(Integer productId) {
		String result = "";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/prueba?characterEncoding=latin1&autoReconnect=true&useSSL=false", user,
					password);
			// here prueba is database name, root is username and password
			Statement stmt = con.createStatement();
			Statement stmt1 = con.createStatement();
			Statement stmt2 = con.createStatement();
			ResultSet r1 = stmt1.executeQuery("SELECT count(*) from product;");
			r1.next();
			Integer n1 = r1.getInt(1);
			stmt.executeUpdate("DELETE FROM product WHERE product_id='" + productId + "';");
			ResultSet r2 = stmt2.executeQuery("SELECT count(*) from product;");
			r2.next();
			Integer n2 = r2.getInt(1);
			con.close();
			if (n1 != n2) {
				result = "Product " + productId + " deleted";
			} else {
				result = "Product " + productId + " not deleted";

			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return result;

	}

	public static Product getProductById(Integer productId) {
		ProductImpl product = new ProductImpl();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/prueba?characterEncoding=latin1&autoReconnect=true&useSSL=false", user,
					password);
			// here prueba is database name, root is username and password
			Statement stmt = con.createStatement();
			ResultSet result = stmt.executeQuery("SELECT * FROM product WHERE product_id='" + productId + "';");
			result.next();
			product.setProductId(result.getInt(1));
			product.setProductName(result.getString(2));
			product.setProductPrice(result.getDouble(3));
			product.setProductCount(result.getInt(4));
			product.setProductCategory(result.getInt(5));
			product.setShopId(result.getInt(6));
			product.setProductImage(result.getString(7));
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return product;
	}

	public static Product getProductByName(String productName) {
		ProductImpl product = new ProductImpl();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/prueba?characterEncoding=latin1&autoReconnect=true&useSSL=false", user,
					password);
			// here prueba is database name, root is username and password
			Statement stmt = con.createStatement();
			ResultSet result = stmt.executeQuery("SELECT * FROM product WHERE product_name='" + productName + "';");
			result.next();
			product.setProductId(result.getInt(1));
			product.setProductName(result.getString(2));
			product.setProductPrice(result.getDouble(3));
			product.setProductCount(result.getInt(4));
			product.setProductCategory(result.getInt(5));
			product.setShopId(result.getInt(6));
			product.setProductImage(result.getString(7));

			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return product;
	}

	public static String deleteProductByName(String productName) {
		String result ="";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/smart_shopping?characterEncoding=latin1&autoReconnect=true&useSSL=false", user,
					password);
			// here prueba is database name, root is username and password
			Statement stmt = con.createStatement();
			Statement stmt1 = con.createStatement();
			Statement stmt2 = con.createStatement();
			ResultSet r1 = stmt1.executeQuery("SELECT count(*) from product;");
			r1.next();
			Integer n1 = r1.getInt(1);
			stmt.executeUpdate("DELETE FROM product WHERE product_name='" + productName + "';");
			ResultSet r2 = stmt2.executeQuery("SELECT count(*) from product;");
			r2.next();
			Integer n2 = r2.getInt(1);
			con.close();
			if (n1 != n2) {
				result = "Product " + productName + " deleted";
			} else {
				result = "Product " + productName + " not deleted";

			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return result;

	}

	public static List<ProductImpl> getAll() {
		List<ProductImpl> products = new ArrayList<>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/prueba?characterEncoding=latin1&autoReconnect=true&useSSL=false", user,
					password);
			// here prueba is database name, root is username and password
			Statement stmt = con.createStatement();
			ResultSet result = stmt.executeQuery("SELECT * FROM product;");
			while (result.next()) {
				ProductImpl product = new ProductImpl(result.getInt(1), result.getString(2), result.getDouble(3),
						result.getInt(4), result.getInt(5), result.getInt(6), result.getString(7));
				products.add(product);

			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return products;
	}

	public static List<ProductImpl> getProductsLimit(Integer numberOfRowsToReturn, Integer startInRow) {
		List<ProductImpl> products = new ArrayList<>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/prueba?characterEncoding=latin1&autoReconnect=true&useSSL=false", user,
					password);
			// here prueba is database name, root is username and password
			Statement stmt = con.createStatement();
			ResultSet result = stmt.executeQuery(
					"SELECT * FROM product LIMIT " + numberOfRowsToReturn + " OFFSET " + startInRow + ";");
			while (result.next()) {
				ProductImpl product = new ProductImpl(result.getInt(1), result.getString(2), result.getDouble(3),
						result.getInt(4), result.getInt(5), result.getInt(6), result.getString(7));
				products.add(product);

			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return products;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(int productCategory) {
		this.productCategory = productCategory;
	}

	public String getProductImage() {
		return productImage;
	}

	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}

	public Double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(Double productPrice) {
		this.productPrice = productPrice;
	}

	public int getShopId() {
		return shopId;
	}

	public void setShopId(int shopId) {
		this.shopId = shopId;
	}

	public int getProductCount() {
		return productCount;
	}

	public void setProductCount(int productCount) {
		this.productCount = productCount;
	}

	@Override
	public String toString() {
		return "ProductImpl [productId=" + productId + ", productName=" + productName + ", productCategory="
				+ productCategory + ", productImage=" + productImage + ", productPrice=" + productPrice + ", shopId="
				+ shopId + ", productCount=" + productCount + "]";
	}

//	@Override
//	public Product unmarshal(ProductImpl v) throws Exception {
//		// TODO Auto-generated method stub
//		return (Product) v;
//	}
//
//	@Override
//	public ProductImpl marshal(Product v) throws Exception {
//		// TODO Auto-generated method stub
//		return (ProductImpl) v;
//	}

}
