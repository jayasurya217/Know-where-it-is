package productTest;

import java.util.List;

import org.json.JSONException;

import it.univaq.odws.maven.category.CategoryImpl;
import it.univaq.odws.maven.fetch.ProductFetchImpl;
import it.univaq.odws.maven.product.Product;
import it.univaq.odws.maven.product.ProductImpl;

public class ProductTest {

	public static void main(String[] args) {
//		System.out.println(ProductImpl.getAll());
//		List<ProductImpl> productos = ProductImpl.getAll();
//		for (ProductImpl producto: productos) {
//			System.out.println(producto);
//		}
		CategoryImpl h = new CategoryImpl();
		System.out.println(h.sendCategoriesWithReturn());
		try {
			System.out.println(ProductFetchImpl.fetch("Cosa2", 1));
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		List<ProductImpl> productos2 = ProductImpl.getProductsLimit(3, 0);
//		for (ProductImpl producto: productos2) {
//			System.out.println(producto);
//		}
		//ProductImpl.addNewProduct("Cosa2", 5.62,1 , 1, 1,"imasdkfm");
//		ProductImpl.addNewProduct("Cosa2", "CosaN2", "imasdkfm", 5.62, "32165",4);
//		ProductImpl.addNewProduct("Cosa3", "CosaN3", "imasdkfm", 5.62, "32165",58);
//		ProductImpl.addNewProduct("Cosa4", "CosaN4", "imasdkfm", 5.62, "32165",7);
		// Updating a product
//		ProductImpl.updateProduct("12345", "Actualizado", "Actualizado", "jpg", 1.25, "Actualizado");
//		ProductImpl.updateProductName("12345", "1.0");
//		ProductImpl.updateProductCategory("12345", "2.0");
//		ProductImpl.updateProductImage("12345", "3.0");
//		ProductImpl.updateProductPrice("12345", 4.0);
//		ProductImpl.updateProductCount("1", 12);
//
////		// Deleting a product by its name
////		ProductImpl.deleteProductByName("Cosa");
		// Deleting a product by its id
		System.out.println(ProductImpl.deleteProductById(12345679));
////		// Getting a product by its name
////		Product producto = ProductImpl.getProductByName("Cosa2");
////		System.out.println(producto);
////		// Getting a product by its id
////		Product producto2 = ProductImpl.getProductById("12345678");
////		System.out.println(producto2);
////		// Getting all products of the database
////		System.out.println(ProductImpl.getAll());

	}

}
